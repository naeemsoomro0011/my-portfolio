 // ── THEME ──
    const themeToggle = document.getElementById('themeToggle');
    const icon = themeToggle.querySelector('i');
    if (localStorage.getItem('theme') === 'light') {
        document.body.setAttribute('data-theme','light');
        icon.className = 'fas fa-moon';
    }
    themeToggle.addEventListener('click', () => {
        const isLight = document.body.getAttribute('data-theme') === 'light';
        if (isLight) {
            document.body.removeAttribute('data-theme');
            icon.className = 'fas fa-sun';
            localStorage.setItem('theme','dark');
        } else {
            document.body.setAttribute('data-theme','light');
            icon.className = 'fas fa-moon';
            localStorage.setItem('theme','light');
        }
    });

    // ── NAVBAR ──
    const navbar = document.getElementById('navbar');
    window.addEventListener('scroll', () => {
        navbar.classList.toggle('scrolled', window.scrollY > 50);
    });

    // ── HAMBURGER ──
    const hamburger = document.getElementById('hamburger');
    const navLinks = document.getElementById('navLinks');
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navLinks.classList.toggle('active');
    });
    document.querySelectorAll('.nav-links a').forEach(a => {
        a.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navLinks.classList.remove('active');
        });
    });

    // ── ACTIVE NAV ──
    const sections = document.querySelectorAll('section[id]');
    const navItems = document.querySelectorAll('.nav-links a');
    window.addEventListener('scroll', () => {
        let cur = '';
        sections.forEach(s => { if (window.scrollY >= s.offsetTop - 200) cur = s.id; });
        navItems.forEach(a => {
            a.classList.remove('active');
            if (a.getAttribute('href') === '#' + cur) a.classList.add('active');
        });
    });

    // ── SCROLL REVEAL ──
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            const delay = entry.target.getAttribute('data-delay') || 0;
            setTimeout(() => {
                entry.target.classList.add('reveal');
                const bar = entry.target.querySelector('.progress-fill');
                if (bar) setTimeout(() => { bar.style.width = bar.getAttribute('data-width') + '%'; }, 400);
            }, parseInt(delay));
            observer.unobserve(entry.target);
        });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    document.querySelectorAll('.scroll-reveal, .skill-card, .tl-item, .project-card, .contact-card, .soft-tag').forEach(el => observer.observe(el));

    // ── POPUP ──
    const overlay = document.getElementById('popupOverlay');
    const pSpinner = document.getElementById('popupSpinner');
    const pEmoji = document.getElementById('popupEmoji');
    const pTitle = document.getElementById('popupTitle');
    const pMsg = document.getElementById('popupMsg');
    const pFill = document.getElementById('popupFill');
    let timer, redirectUrl = '';

    function showPopup(title, msg, emoji) {
        pTitle.textContent = title;
        pMsg.textContent = msg;
        if (emoji) {
            pSpinner.style.display = 'none';
            pEmoji.style.display = 'block';
            pEmoji.textContent = emoji;
        } else {
            pSpinner.style.display = 'block';
            pEmoji.style.display = 'none';
        }
        pFill.style.transition = 'none';
        pFill.style.width = '0';
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closePopup() {
        overlay.classList.remove('active');
        document.body.style.overflow = '';
        clearTimeout(timer);
        pFill.style.transition = 'none';
        pFill.style.width = '0';
    }

    function animateThenGo(duration, fn) {
        setTimeout(() => {
            pFill.style.transition = `width ${duration}ms linear`;
            pFill.style.width = '100%';
        }, 80);
        timer = setTimeout(() => { fn(); closePopup(); }, duration);
    }

    function openProjectPopup(url, name) {
        redirectUrl = url;
        showPopup('Opening ' + name, 'Launching live demo, please wait...', null);
        animateThenGo(2500, () => window.open(redirectUrl, '_blank'));
    }

    function openContactPopup(type, detail) {
        let url, title, msg, emoji;
        if (type === 'phone') {
            url = 'tel:' + detail;
            title = 'Calling ' + detail;
            msg = 'Opening your phone dialer...';
            emoji = '📞';
        } else if (type === 'whatsapp') {
            url = 'https://wa.me/92' + detail.substring(1);
            title = 'Opening WhatsApp';
            msg = 'Connecting you to direct chat...';
            emoji = '💬';
        } else {
            url = 'mailto:' + detail;
            title = 'Opening Email';
            msg = 'Launching your email client...';
            emoji = '✉️';
        }
        redirectUrl = url;
        showPopup(title, msg, emoji);
        animateThenGo(2200, () => { window.location.href = redirectUrl; });
    }

    function openSocialPopup(url, platform) {
        const emojis = { Facebook:'📘', Instagram:'📸', GitHub:'🐙', WhatsApp:'💬' };
        redirectUrl = url;
        showPopup('Opening ' + platform, 'You will be redirected in a moment...', emojis[platform] || '🔗');
        animateThenGo(3500, () => window.open(redirectUrl, '_blank'));
    }

    overlay.addEventListener('click', e => { if (e.target === overlay) closePopup(); });

    // ── SMOOTH SCROLL ──
    document.querySelectorAll('a[href^="#"]').forEach(a => {
        a.addEventListener('click', e => {
            e.preventDefault();
            const t = document.querySelector(a.getAttribute('href'));
            if (t) t.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });