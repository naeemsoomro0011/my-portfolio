 // ── THEME ──
    const themeToggle = document.getElementById('themeToggle');
    const icon = themeToggle.querySelector('i');
    if (localStorage.getItem('theme') === 'light') {
        document.body.setAttribute('data-theme','light');
        icon.className = 'fas fa-moon';
    }
    themeToggle.addEventListener('click', () => {
        const isLight = document.body.getAttribute('data-theme') === 'light';
        if (isLight) {
            document.body.removeAttribute('data-theme');
            icon.className = 'fas fa-sun';
            localStorage.setItem('theme','dark');
        } else {
            document.body.setAttribute('data-theme','light');
            icon.className = 'fas fa-moon';
            localStorage.setItem('theme','light');
        }
    });

    // ── NAVBAR ──
    const navbar = document.getElementById('navbar');
    window.addEventListener('scroll', () => {
        navbar.classList.toggle('scrolled', window.scrollY > 50);
    });

    // ── HAMBURGER ──
    const hamburger = document.getElementById('hamburger');
    const navLinks = document.getElementById('navLinks');
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navLinks.classList.toggle('active');
    });
    document.querySelectorAll('.nav-links a').forEach(a => {
        a.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navLinks.classList.remove('active');
        });
    });

    // ── ACTIVE NAV ──
    const sections = document.querySelectorAll('section[id]');
    const navItems = document.querySelectorAll('.nav-links a');
    window.addEventListener('scroll', () => {
        let cur = '';
        sections.forEach(s => { if (window.scrollY >= s.offsetTop - 200) cur = s.id; });
        navItems.forEach(a => {
            a.classList.remove('active');
            if (a.getAttribute('href') === '#' + cur) a.classList.add('active');
        });
    });

    // ── SCROLL REVEAL ──
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            const delay = entry.target.getAttribute('data-delay') || 0;
            setTimeout(() => {
                entry.target.classList.add('reveal');
                const bar = entry.target.querySelector('.progress-fill');
                if (bar) setTimeout(() => { bar.style.width = bar.getAttribute('data-width') + '%'; }, 400);
            }, parseInt(delay));
            observer.unobserve(entry.target);
        });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    document.querySelectorAll('.scroll-reveal, .skill-card, .tl-item, .project-card, .contact-card, .soft-tag').forEach(el => observer.observe(el));

    // ── POPUP ──
    const overlay = document.getElementById('popupOverlay');
    const pSpinner = document.getElementById('popupSpinner');
    const pEmoji = document.getElementById('popupEmoji');
    const pTitle = document.getElementById('popupTitle');
    const pMsg = document.getElementById('popupMsg');
    const pFill = document.getElementById('popupFill');
    let timer, redirectUrl = '';

    function showPopup(title, msg, emoji) {
        pTitle.textContent = title;
        pMsg.textContent = msg;
        if (emoji) {
            pSpinner.style.display = 'none';
            pEmoji.style.display = 'block';
            pEmoji.textContent = emoji;
        } else {
            pSpinner.style.display = 'block';
            pEmoji.style.display = 'none';
        }
        pFill.style.transition = 'none';
        pFill.style.width = '0';
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closePopup() {
        overlay.classList.remove('active');
        document.body.style.overflow = '';
        clearTimeout(timer);
        pFill.style.transition = 'none';
        pFill.style.width = '0';
    }

    function animateThenGo(duration, fn) {
        setTimeout(() => {
            pFill.style.transition = `width ${duration}ms linear`;
            pFill.style.width = '100%';
        }, 80);
        timer = setTimeout(() => { fn(); closePopup(); }, duration);
    }

    function openProjectPopup(url, name) {
        redirectUrl = url;
        showPopup('Opening ' + name, 'Launching live demo, please wait...', null);
        animateThenGo(2500, () => window.open(redirectUrl, '_blank'));
    }

    function openContactPopup(type, detail) {
        let url, title, msg, emoji;
        if (type === 'phone') {
            url = 'tel:' + detail;
            title = 'Calling ' + detail;
            msg = 'Opening your phone dialer...';
            emoji = '📞';
        } else if (type === 'whatsapp') {
            url = 'https://wa.me/92' + detail.substring(1);
            title = 'Opening WhatsApp';
            msg = 'Connecting you to direct chat...';
            emoji = '💬';
        } else {
            url = 'mailto:' + detail;
            title = 'Opening Email';
            msg = 'Launching your email client...';
            emoji = '✉️';
        }
        redirectUrl = url;
        showPopup(title, msg, emoji);
        animateThenGo(2200, () => { window.location.href = redirectUrl; });
    }

    function openSocialPopup(url, platform) {
        const emojis = { Facebook:'📘', Instagram:'📸', GitHub:'🐙', WhatsApp:'💬' };
        redirectUrl = url;
        showPopup('Opening ' + platform, 'You will be redirected in a moment...', emojis[platform] || '🔗');
        animateThenGo(3500, () => window.open(redirectUrl, '_blank'));
    }

    overlay.addEventListener('click', e => { if (e.target === overlay) closePopup(); });

    // ── CV / RESUME DOWNLOAD POPUP ──
    const dlOverlay = document.getElementById('dlOverlay');
    const dlLoadingView = document.getElementById('dlLoadingView');
    const dlSuccessView = document.getElementById('dlSuccessView');
    const dlRingFg = document.getElementById('dlRingFg');
    const dlPercent = document.getElementById('dlPercent');
    const dlLoadingTitle = document.getElementById('dlLoadingTitle');
    const dlLoadingMsg = document.getElementById('dlLoadingMsg');
    const dlSuccessTitle = document.getElementById('dlSuccessTitle');
    const dlSuccessMsg = document.getElementById('dlSuccessMsg');
    const dlRingIcon = document.getElementById('dlRingIcon');

    const RING_CIRCUMFERENCE = 326.7;
    let dlInterval = null;

    const dlFiles = {
        cv: {
            url: './assets/Muhammad-Naeem-CV.pdf',
            filename: 'Muhammad-Naeem-CV.pdf',
            label: 'CV',
            loadingMsg: "Thanks for checking out my work — preparing your CV now 🚀",
            successMsg: "Your CV has landed safely — thanks for stopping by my portfolio!"
        },
        resume: {
            url: './assets/Muhammad-Naeem-Resume.pdf',
            filename: 'Muhammad-Naeem-Resume.pdf',
            label: 'Resume',
            loadingMsg: "Thanks for your interest — preparing my Resume now 🚀",
            successMsg: "Your Resume has landed safely — thanks for stopping by my portfolio!"
        }
    };

    function startDownload(type) {
        const data = dlFiles[type];
        if (!data) return;

        // reset to loading view
        dlLoadingView.style.display = 'block';
        dlSuccessView.style.display = 'none';
        dlRingFg.style.stroke = "url(#dlGradient)";
        dlRingFg.style.strokeDashoffset = RING_CIRCUMFERENCE;
        dlPercent.textContent = '0%';
        dlLoadingTitle.textContent = 'Downloading ' + data.label + '...';
        dlLoadingMsg.textContent = data.loadingMsg;
        dlRingIcon.innerHTML = '<i class="fas fa-file-pdf"></i>';

        dlOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';

        let progress = 0;
        clearInterval(dlInterval);
        dlInterval = setInterval(() => {
            progress += Math.random() * 12 + 6;
            if (progress >= 100) {
                progress = 100;
                clearInterval(dlInterval);
                const offset = RING_CIRCUMFERENCE - (progress / 100) * RING_CIRCUMFERENCE;
                dlRingFg.style.strokeDashoffset = offset;
                dlPercent.textContent = '100%';

                // trigger the actual file download
                const link = document.createElement('a');
                link.href = data.url;
                link.download = data.filename;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);

                setTimeout(() => showDownloadSuccess(data), 500);
                return;
            }
            const offset = RING_CIRCUMFERENCE - (progress / 100) * RING_CIRCUMFERENCE;
            dlRingFg.style.strokeDashoffset = offset;
            dlPercent.textContent = Math.floor(progress) + '%';
        }, 180);
    }

    function showDownloadSuccess(data) {
        dlLoadingView.style.display = 'none';
        dlSuccessView.style.display = 'block';
        dlSuccessTitle.textContent = 'Download Successful! ✅';
        dlSuccessMsg.textContent = data.successMsg;
    }

    function closeDownloadPopup() {
        dlOverlay.classList.remove('active');
        document.body.style.overflow = '';
        clearInterval(dlInterval);
    }

    dlOverlay.addEventListener('click', e => { if (e.target === dlOverlay) closeDownloadPopup(); });

    // ── MORE PROJECTS POPUP ──
    const mpOverlay = document.getElementById('mpOverlay');

    function openMoreProjects() {
        mpOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeMoreProjects() {
        mpOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    mpOverlay.addEventListener('click', e => { if (e.target === mpOverlay) closeMoreProjects(); });

    // ── MORE REVIEWS POPUP ──
    const mrOverlay = document.getElementById('mrOverlay');

    function openMoreReviews() {
        mrOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeMoreReviews() {
        mrOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    mrOverlay.addEventListener('click', e => { if (e.target === mrOverlay) closeMoreReviews(); });
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') { closeMoreProjects(); closeMoreReviews(); }
    });

    // ── SMOOTH SCROLL ──
    document.querySelectorAll('a[href^="#"]').forEach(a => {
        a.addEventListener('click', e => {
            e.preventDefault();
            const t = document.querySelector(a.getAttribute('href'));
            if (t) t.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });