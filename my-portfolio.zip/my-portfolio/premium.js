/* ═══════════ PREMIUM LAYER — loader, sweet alerts, motion ═══════════ */
(function () {
  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ── LOADER ──
  const splash = $('#mnLoader'), t0 = performance.now();
  const ready = () => { splash.classList.add('hide'); document.body.classList.add('is-ready'); };
  addEventListener('load', () => setTimeout(ready, Math.max(0, 850 - (performance.now() - t0))));
  setTimeout(ready, 3500);
  window.mnBusy = (ms, fn) => {
    splash.classList.remove('hide'); splash.classList.add('busy');
    setTimeout(() => { splash.classList.add('hide'); fn && fn(); setTimeout(() => splash.classList.remove('busy'), 600); }, ms);
  };
  ['openMoreProjects', 'openMoreReviews'].forEach(n => { const f = window[n]; window[n] = () => mnBusy(600, f); });

  // ── SWEET ALERTS ──
  const icons = { success: 'fa-check', info: 'fa-info', warning: 'fa-triangle-exclamation', error: 'fa-xmark' };
  const root = document.body.appendChild(Object.assign(document.createElement('div'), { id: 'mnToasts' }));
  window.mnAlert = ({ icon = 'info', title = '', text = '', duration = 3600 } = {}) => {
    const el = document.createElement('div');
    el.className = 'mn-toast ' + icon; el.style.setProperty('--d', duration + 'ms');
    el.innerHTML = `<div class="mn-ico"><i class="fas ${icons[icon]}"></i></div><div><div class="mn-t"></div><div class="mn-s"></div></div><button class="mn-x" aria-label="Close"><i class="fas fa-times"></i></button><span class="mn-bar"></span>`;
    $('.mn-t', el).textContent = title; $('.mn-s', el).textContent = text;
    const kill = () => { el.classList.add('out'); setTimeout(() => el.remove(), 400); };
    $('.mn-x', el).onclick = kill; root.appendChild(el);
    while (root.children.length > 3) root.firstChild.remove();
    setTimeout(kill, duration);
  };
  window.mnModal = ({ icon = 'warning', title, text, confirm = 'OK', cancel, onConfirm }) => {
    const m = document.createElement('div'); m.className = 'mn-modal';
    m.innerHTML = `<div class="box mn-toast ${icon}" style="animation:modalIn .55s var(--spring) both"><div class="mn-ico"><i class="fas ${icons[icon]}"></i></div><h3></h3><p></p><div class="row"></div></div>`;
    $('h3', m).textContent = title; $('p', m).textContent = text;
    const row = $('.row', m), close = () => { m.style.opacity = 0; setTimeout(() => m.remove(), 250); };
    const mk = (label, cls, fn) => { const b = document.createElement('button'); b.className = 'btn ' + cls; b.textContent = label; b.onclick = () => { close(); fn && fn(); }; row.appendChild(b); };
    mk(confirm, 'btn-primary', onConfirm); if (cancel) mk(cancel, 'btn-outline');
    m.onclick = e => { if (e.target === m) close(); }; document.body.appendChild(m);
  };

  // hooks used by script.js
  window.safeOpen = (url, name) => {
    const w = window.open(url, '_blank');
    if (w) mnAlert({ icon: 'success', title: (name || 'Link') + ' opened', text: 'Opened in a new tab.' });
    else mnModal({ title: 'Pop-up blocked', text: 'Your browser blocked the new tab. Open ' + (name || 'the link') + ' manually?', confirm: 'Open now', cancel: 'Not now', onConfirm: () => (location.href = url) });
  };
  window.cancelPopup = () => { closePopup(); mnAlert({ icon: 'warning', title: 'Cancelled', text: 'Nothing was opened.' }); };
  window.mnContactDone = (type, detail) => {
    if (type === 'whatsapp') return;
    navigator.clipboard && navigator.clipboard.writeText(detail).then(() =>
      mnAlert({ icon: 'success', title: (type === 'email' ? 'Email' : 'Number') + ' copied', text: detail })).catch(() => {});
  };

  // Esc closes the popups that script.js does not cover
  addEventListener('keydown', e => { if (e.key === 'Escape') { closePopup(); closeDownloadPopup(); } });

  // ── SCROLL BAR ──
  const bar = $('#scrollBar');
  addEventListener('scroll', () => { bar.style.transform = `scaleX(${scrollY / (document.documentElement.scrollHeight - innerHeight || 1)})`; }, { passive: true });

  // ── CURSOR SPOTLIGHT ON CARDS ──
  document.addEventListener('pointermove', e => {
    const c = e.target.closest && e.target.closest('.highlight-item,.skill-card,.testi-card,.contact-card,.tl-card');
    if (!c) return; const r = c.getBoundingClientRect();
    c.style.setProperty('--mx', e.clientX - r.left + 'px'); c.style.setProperty('--my', e.clientY - r.top + 'px');
  }, { passive: true });

  // ── 3D TILT + MAGNETIC BUTTONS ──
  if (!reduce && matchMedia('(hover:hover)').matches) $$('.btn,.project-btn,.c-btn,.more-projects-btn,.theme-toggle').forEach(b => {
    b.addEventListener('pointermove', e => { const r = b.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
      b.style.translate = `${x * 10}px ${y * 8}px`; b.style.setProperty('--rx', -y * 14 + 'deg'); b.style.setProperty('--ry', x * 14 + 'deg'); });
    b.addEventListener('pointerleave', () => { b.style.translate = ''; b.style.removeProperty('--rx'); b.style.removeProperty('--ry'); });
  });

  // ── COUNT-UP STATS ──
  const io = new IntersectionObserver(es => es.forEach(en => {
    if (!en.isIntersecting) return; io.unobserve(en.target);
    const el = en.target, m = el.textContent.match(/^(\d+)(.*)$/); if (!m) return;
    const end = +m[1], t = performance.now();
    (function tick(n) { const p = Math.min((n - t) / 1400, 1); el.textContent = Math.round(end * (1 - Math.pow(1 - p, 3))) + m[2]; if (p < 1) requestAnimationFrame(tick); })(t);
  }), { threshold: .6 });
  $$('.stat-num').forEach(el => io.observe(el));

  // ── SOCIAL ICONS: keyboard access ──
  $$('.social-btn').forEach(b => b.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); b.click(); } }));
})();

/* ═══════════ ROUND 2 — theme swap, tooltips, dock, project search ═══════════ */
(function () {
  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ── THEME: circular reveal from the switch ──
  window.mnThemeSwap = fn => {
    if (reduce || !document.startViewTransition) return fn();
    const r = $('#themeToggle').getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2, R = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y));
    document.startViewTransition(fn).ready.then(() => document.documentElement.animate(
      { clipPath: [`circle(0 at ${x}px ${y}px)`, `circle(${R}px at ${x}px ${y}px)`] },
      { duration: 750, easing: 'cubic-bezier(.22,1,.36,1)', pseudoElement: '::view-transition-new(root)' }));
  };

  // ── TOOLTIPS: hover on desktop, tap on touch. Any [data-tip] works; TIPS covers the rest automatically ──
  const TIPS = { '.theme-toggle': 'Switch theme', '.hamburger': 'Menu', '.logo': 'Home', '.btn-download': 'Download PDF', '.project-btn': 'Open live demo', '.c-btn': 'Get in touch',
    '.more-projects-btn': 'See everything', '.mp-close,.dl-close': 'Close', '.ps-clear': 'Clear search', '.ps-chip': 'Filter by this' };
  const tip = document.body.appendChild(Object.assign(document.createElement('div'), { id: 'mnTip' }));
  let cur, hideT, last = 'mouse';
  const find = t => { for (let el = t; el && el.matches; el = el.parentElement) { if (el.matches('.social-btn,.dk')) return []; if (el.dataset && el.dataset.tip) return [el, el.dataset.tip]; for (const s in TIPS) if (el.matches(s)) return [el, TIPS[s]]; } return []; };
  const show = (el, txt) => {
    const was = tip.classList.contains('on'); tip.textContent = txt;
    const r = el.getBoundingClientRect(), w = tip.offsetWidth, h = tip.offsetHeight, g = 14; let pos = el.dataset.tipPos || 'top', x, y;
    const place = p => { if (p === 'left') { x = r.left - w - g; y = r.top + r.height / 2 - h / 2; } else if (p === 'bottom') { x = r.left + r.width / 2 - w / 2; y = r.bottom + g; } else { x = r.left + r.width / 2 - w / 2; y = r.top - h - g; } };
    place(pos); if (pos === 'left' && x < 8) place(pos = 'top'); if (pos === 'top' && y < 8) place(pos = 'bottom');
    const cx = Math.min(Math.max(x, 8), innerWidth - w - 8);
    tip.style.setProperty('--x', cx + 'px'); tip.style.setProperty('--y', y + 'px');
    tip.style.setProperty('--ax', Math.min(Math.max(r.left + r.width / 2 - cx, 12), w - 12) + 'px'); tip.style.setProperty('--ay', r.top + r.height / 2 - y + 'px');
    tip.className = (was ? '' : 'snap ') + 'on ' + pos; // snap = appear in place, glide only between targets
  };
  const hide = () => { cur = null; tip.classList.remove('on'); };
  document.addEventListener('pointerover', e => { if (e.pointerType === 'touch') return; const [el, t] = find(e.target); if (!el) return hide(); if (el !== cur) { cur = el; show(el, t); } });
  document.addEventListener('pointerout', e => { if (!e.relatedTarget) hide(); });
  document.addEventListener('pointerdown', e => {
    last = e.pointerType; if (e.pointerType === 'mouse') return;
    const b = e.target.closest('.social-btn,.dk'); if (b) return b.classList.add('is-active');
    const [el, t] = find(e.target); if (!el) return; show(el, t); clearTimeout(hideT); hideT = setTimeout(hide, 1600);
  }, true);
  ['pointercancel', 'scroll'].forEach(n => addEventListener(n, () => { hide(); $$('.is-active').forEach(b => b.classList.remove('is-active')); }, { passive: true }));
  // on touch, let the pop + tooltip play before the popup opens
  document.addEventListener('click', e => {
    const b = e.target.closest('.social-btn,.dk');
    if (b && !b._go && last !== 'mouse' && e.detail) {
      e.preventDefault(); e.stopImmediatePropagation(); b.classList.add('is-active');
      return setTimeout(() => { b._go = 1; hide(); b.click(); b._go = 0; b.classList.remove('is-active'); }, 480);
    }
    hide();
  }, true);

  // ── SIDE DOCK: the same five icons as the footer (laptop/desktop only; mobile uses the footer) ──
  const dock = document.body.appendChild(Object.assign(document.createElement('nav'), { className: 'dock' }));
  dock.setAttribute('aria-label', 'Quick contact');
  const items = $$('.social-btn').map(b => [b.className.replace('social-btn', '').trim(), b.querySelector('i').className, b.dataset.tip, b.getAttribute('onclick')]);
  items.forEach(([c, ic, t, fn], i) => {
    const b = document.createElement('button'); b.className = 'dk ' + c; b.style.setProperty('--i', i); b.dataset.tip = t; b.dataset.tipPos = 'left';
    b.setAttribute('aria-label', t); b.setAttribute('onclick', fn); b.innerHTML = `<i class="${ic}"></i>`; dock.appendChild(b);
  });

  // ── PROJECT SEARCH: indexes every .project-card at runtime, so new projects are searchable with zero extra code ──
  const grid = $('.projects-grid'); if (!grid) return;
  const norm = s => s.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(), esc = s => s.replace(/"/g, '&quot;');
  const wrap = document.createElement('div'); wrap.className = 'ps-wrap';
  wrap.innerHTML = `<label class="ps-box"><i class="fas fa-magnifying-glass ps-ico"></i><input id="psInput" type="search" autocomplete="off" spellcheck="false" aria-label="Search projects"><kbd>/</kbd><button type="button" class="ps-clear" aria-label="Clear search"><i class="fas fa-times"></i></button></label><div class="ps-meta"><span id="psCount"></span><button type="button" class="ps-more"></button></div><div class="ps-chips"></div>`;
  grid.before(wrap);
  const empty = document.createElement('div'); empty.className = 'ps-empty';
  empty.innerHTML = '<div class="ps-lens"><i class="fas fa-magnifying-glass"></i></div><h3></h3><p>Try a technology like React or a client name.</p><button type="button" class="btn btn-primary"></button>'; grid.after(empty);
  const inp = $('#psInput'), count = $('#psCount'), more = $('.ps-more', wrap), chips = $('.ps-chips', wrap), eb = $('button', empty);
  const note = document.createElement('p'); note.className = 'ps-note'; note.innerHTML = '<i class="fas fa-filter"></i> <span></span><button type="button">Clear</button>';
  const mh = $('#mpOverlay .mp-header'); mh && mh.append(note);
  let cards = [], sig = '', mMore = 0;
  const lev = (a, b) => { if (Math.abs(a.length - b.length) > 2) return 9; const d = [...Array(b.length + 1).keys()];
    for (let i = 1; i <= a.length; i++) { let p = d[0]; d[0] = i; for (let j = 1; j <= b.length; j++) { const t = d[j]; d[j] = Math.min(d[j] + 1, d[j - 1] + 1, p + (a[i - 1] === b[j - 1] ? 0 : 1)); p = t; } } return d[b.length]; };
  const hit = (c, q) => q.every(t => c.n.includes(t) || c.c.includes(t) || (t.length > 3 && c.w.some(w => lev(t, w) <= (t.length > 5 ? 2 : 1))));
  const index = () => {
    cards = $$('.project-card').map(el => { const tags = $$('.project-tag', el).map(x => x.textContent.trim());
      const n = norm([$('.project-name', el)?.textContent, $('.project-desc', el)?.textContent, tags.join(' '), $('.project-stars span', el)?.textContent].join(' '));
      return { el, tags, n, c: n.replace(/ /g, ''), w: n.split(' '), more: !!el.closest('.mp-overlay') }; });
    const f = {}; cards.forEach(c => c.tags.forEach(t => { f[norm(t)] = f[norm(t)] || t.replace(/\s+/g, ' '); }));
    chips.innerHTML = Object.entries(f).map(([k, t]) => [t, cards.filter(c => hit(c, k.split(' '))).length]).sort((a, b) => b[1] - a[1]).slice(0, 8)
      .map(([t, n]) => `<button type="button" class="ps-chip" data-q="${esc(t)}">${t}<b>${n}</b></button>`).join('');
  };
  const apply = () => {
    const raw = inp.value.trim(), q = norm(raw).split(' ').filter(Boolean); let a = 0, b = 0; const vis = [];
    wrap.classList.toggle('has-q', !!raw); grid.classList.toggle('filtering', !!raw);
    cards.forEach(c => { const ok = !q.length || hit(c, q); c.el.classList.toggle('ps-hide', !ok); if (!ok) return; c.more ? b++ : (a++, vis.push(c.el)); });
    const s = cards.map(c => +!c.el.classList.contains('ps-hide')).join('');
    if (s !== sig) { if (sig || raw) vis.forEach((el, i) => { el.classList.add('reveal'); el.style.setProperty('--i', i); el.classList.remove('ps-in'); void el.offsetWidth; el.classList.add('ps-in'); setTimeout(() => el.classList.remove('ps-in'), 900 + i * 70); }); sig = s; }
    mMore = b; const m = a + b;
    count.textContent = raw ? (m ? `${m} of ${cards.length} projects match` : 'No matches found') : `${cards.length} projects — start typing to search`;
    more.classList.toggle('on', !!raw && b > 0 && a > 0); more.textContent = `+${b} more in More Projects`;
    const none = !!raw && a === 0; empty.classList.toggle('on', none);
    if (none) { $('h3', empty).textContent = b ? `${b} match${b > 1 ? 'es' : ''} in More Projects` : `No project matches “${raw}”`; eb.innerHTML = b ? '<i class="fas fa-layer-group"></i> Open More Projects' : '<i class="fas fa-rotate-left"></i> Clear search'; }
    note.classList.toggle('on', !!raw); $('span', note).textContent = b ? `Showing ${b} match${b > 1 ? 'es' : ''} for “${raw}”` : `No matches here for “${raw}”`;
    $$('.ps-chip', chips).forEach(c => c.classList.toggle('on', !!raw && norm(c.dataset.q) === norm(raw)));
  };
  const clear = () => { inp.value = ''; apply(); };
  inp.addEventListener('input', apply);
  inp.addEventListener('keydown', e => {
    if (e.key === 'Escape') { clear(); inp.blur(); }
    if (e.key === 'Enter') { e.preventDefault(); const f = cards.find(c => !c.more && !c.el.classList.contains('ps-hide'));
      if (f) { f.el.scrollIntoView({ behavior: 'smooth', block: 'center' }); f.el.classList.add('ps-pulse'); setTimeout(() => f.el.classList.remove('ps-pulse'), 1500); } else if (mMore) openMoreProjects(); }
  });
  addEventListener('keydown', e => { if (e.key === '/' && !/input|textarea/i.test(document.activeElement.tagName)) { e.preventDefault(); inp.focus({ preventScroll: true }); wrap.scrollIntoView({ behavior: 'smooth', block: 'center' }); } });
  $('.ps-clear', wrap).onclick = () => { clear(); inp.focus(); };
  chips.onclick = e => { const c = e.target.closest('.ps-chip'); if (!c) return; inp.value = norm(inp.value) === norm(c.dataset.q) ? '' : c.dataset.q; apply(); };
  more.onclick = () => openMoreProjects(); eb.onclick = () => (mMore ? openMoreProjects() : clear()); $('button', note).onclick = clear;
  index(); apply();
  const mo = new MutationObserver(() => { index(); apply(); }); mo.observe(grid, { childList: true }); $$('.mp-grid').forEach(g => mo.observe(g, { childList: true }));
  new IntersectionObserver((es, o) => es.forEach(en => { if (en.isIntersecting) { wrap.classList.add('in'); o.disconnect(); } }), { threshold: .25 }).observe(wrap);
  // typewriter placeholder built from real project names
  let k = 0, j = 0, del = 0; (function tick() {
    const w = [...new Set(cards.map(c => $('.project-name', c.el)?.textContent.trim()).filter(Boolean))];
    if (inp.value || document.activeElement === inp || reduce || !w.length) { inp.placeholder = 'Search projects, tech or clients…'; return setTimeout(tick, 700); }
    const s = w[k % w.length]; j += del ? -1 : 1; inp.placeholder = 'Search “' + s.slice(0, j) + '”'; let d = del ? 35 : 70;
    if (!del && j >= s.length) { del = 1; d = 1300; } else if (del && j <= 0) { del = 0; k++; d = 350; } setTimeout(tick, d);
  })();
})();
